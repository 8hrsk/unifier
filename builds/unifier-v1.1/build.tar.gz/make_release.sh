#!/bin/bash

# Получаем текущую дату и время в формате YYYYMMDD_HHMMSS
current_time=$(date +"%Y%m%d_%H%M%S")

# Имя директории
dir_name="build${current_time}"

# Создаем директорию
mkdir ./builds/"$dir_name"

# Сообщение об успешном создании
echo "Directory '$dir_name' created. Creating .deb file..."

dpkg-deb --build ../unifier
mv ../unifier.deb ./builds/"$dir_name"/unifier.deb

echo ".deb file created successfully. Creating a tar.gz file..."

tar -czvf ./builds/"$dir_name"/build.tar.gz ./DEBIAN ./opt ./usr ./.gitignore build.sh make_release.sh Readme.md

echo "Tar.gz file created successfully! Release is ready"
